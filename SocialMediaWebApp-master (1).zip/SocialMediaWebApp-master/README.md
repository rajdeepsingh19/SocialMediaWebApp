# SocialMediaWebApp
 It is a web application similar to Facebook where user can register/login and do post the message. Other user can like and save the post and can also chat.  
